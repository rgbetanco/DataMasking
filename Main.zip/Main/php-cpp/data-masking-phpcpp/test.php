<?php
	echo "test\n";
	Options("123", "789");
?>
