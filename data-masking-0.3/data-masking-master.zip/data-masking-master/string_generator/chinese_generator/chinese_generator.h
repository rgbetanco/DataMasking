#ifndef CHINESE_GENERATOR_H
#define CHINESE_GENERATOR_H

void gen_trad_chiniese_text(char* output, const unsigned int cnt);
#endif