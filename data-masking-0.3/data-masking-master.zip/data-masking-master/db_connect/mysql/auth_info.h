#ifndef AUTH_INFO_H_
#define AUTH_INFO_H_

#define HOST "localhost"
#define USER "root"
#define PASSWORD "your_password"

#endif // AUTH_INFO_H_