# MySQL Test Data Generate Tools
## Descriptions
* create_db_table.cpp
  * Create a single column table database.
* select_table_hk_address.cpp
  * Print the table data of the above-created database.

## Usage
```
/db_connect/mysql/tools$ make
/db_connect/mysql/tools$ ./create_db_table.out
/db_connect/mysql/tools$ ./select_table_hk_address.out
```